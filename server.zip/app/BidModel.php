<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BidModel extends Model
{
    
	protected $table = 'bid';
	protected $primary_key = 'id';
}
