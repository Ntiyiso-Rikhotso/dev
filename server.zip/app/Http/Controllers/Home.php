<?php

namespace App\Http\Controllers;


class Home extends Controller
{
    
}
